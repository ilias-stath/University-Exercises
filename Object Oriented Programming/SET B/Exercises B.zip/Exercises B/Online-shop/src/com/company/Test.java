package com.company;

import java.util.Scanner;

public class Test {

    public static void main(String[] args){
        int iC;
        Scanner input = new Scanner(System.in);
        Sales sale = new Sales();

        //Setting the Purchases
        ShopPurchase sp1 = new ShopPurchase(1,5f,"Stelios",5);
        ShopPurchase sp2 = new ShopPurchase(5,10f,"Ilias",5);
        ShopPurchase sp3 = new ShopPurchase(10,2f,"Ilias",5);
        ShopPurchase sp4 = new ShopPurchase(23,16f,"Stelios",5);
        OnlinePurchase op1 = new OnlinePurchase(5,20f,"Kozani 1",5);
        OnlinePurchase op2 = new OnlinePurchase(22,1f,"Kozani 2",4);
        OnlinePurchase op3 = new OnlinePurchase(12,40f,"Kozani 3",2);
        OnlinePurchase op4 = new OnlinePurchase(23,12f,"Kozani 4",8);

        //Putting the purchases in the array
        sale.setPurchases(sp1);
        sale.setPurchases(sp2);
        sale.setPurchases(sp3);
        sale.setPurchases(sp4);
        sale.setPurchases(op1);
        sale.setPurchases(op2);
        sale.setPurchases(op3);
        sale.setPurchases(op4);

        //Calling the functions
        System.out.println("-------------------------------------------");
        System.out.println("Total amount:" + sale.calculateRevenue());
        System.out.println("-------------------------------------------");
        sale.highestProf();
        System.out.println("-------------------------------------------");
        sale.OnRev_ShopRev();
        System.out.println("-------------------------------------------");
        System.out.println("Type an item code to see it's total revenue and sold times.");
        iC = input.nextInt();
        sale.TotalItemSold(iC);

    }
}
