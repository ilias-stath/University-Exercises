package com.company;

public class ShopPurchase extends Purchase{
    private String assistant;
    private int tax;

    //Constructor without parameters
    public ShopPurchase(){
        super(0,0.0f);
        assistant = " ";
        tax = 0;
    }

    //Constructor with parameters
    public ShopPurchase(int iC, float am, String assistant, int tax){
        super(iC, am);
        this.assistant = assistant;
        this.tax = tax;
    }

    //Set and get Functions
    public void setTax(int tax){
        this.tax = tax;
    }

    public void setAssistant(String assistant){
        this.assistant = assistant;
    }

    public int getTax(){
        return tax;
    }

    public String getAssistant(){
        return assistant;
    }

    //Overriding toString and calling toString from Purchase
    @Override
    public String toString() {
        return super.toString() + "Assistant='" + assistant + "'\nTax=" + tax + "\nTotal expenses:" + calculateAmount() + "\n";
    }

    //Overriding calculateAmount and calling getAmount from Purchase
    @Override
    public float calculateAmount() {
        float amount;

        amount = super.getAmount() + super.getAmount()*((float)tax/100f);

        return amount;
    }
}
