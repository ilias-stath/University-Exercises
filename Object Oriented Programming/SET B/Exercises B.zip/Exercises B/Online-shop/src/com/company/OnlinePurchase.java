package com.company;

import java.util.Scanner;

public class OnlinePurchase extends Purchase{
    private String address;
    private float shippingCost;

    //Constructor without parameters
    public OnlinePurchase(){
        super(0,0.0f); //Calling the constructor with parameters from Purchase
        address = " ";
        shippingCost = 0.0f;
    }

    //Constructor with parameters
    public OnlinePurchase(int iC, float am, String address, float shippingCost){
        super(iC, am); //Calling the constructor with parameters from Purchase
        this.address = address;
        this.shippingCost = shippingCost;
    }

    //Functions set and get
    public void setAddress(String address) {
        this.address = address;
    }

    public void setShippingCost(float shippingCost) {
        this.shippingCost = shippingCost;
    }

    public float getShippingCost() {
        return shippingCost;
    }

    public String getAddress(){
        return address;
    }

    //Function read
    public void read(){
        super.read(); //Calling the function read from Purchase

        Scanner input = new Scanner(System.in);

        System.out.println("Type your address:");
        address = input.next();

        //Check for the shipping cost
        do{
            System.out.println("Type the shipping cost:");
            shippingCost = input.nextFloat();
            if(shippingCost < 0){
                System.out.println("Error. Shipping cost cannot be a negative number.");
            }
        }while(shippingCost < 0);

    }

    //Overriding toString and calling the toString from Purchase
    @Override
    public String toString() {
        return super.toString() + "Address:" + getAddress() + "\nShipping Cost:" + getShippingCost() + "\nTotal expenses:" + calculateAmount() + "\n";
    }

    //Overriding calculateAmount and calling the getAmount from Purchase
    @Override
    public float calculateAmount() {
        float amount;

        amount = super.getAmount()+shippingCost + (super.getAmount()+shippingCost)*(13.0f/100.0f);

        return amount;
    }
}
