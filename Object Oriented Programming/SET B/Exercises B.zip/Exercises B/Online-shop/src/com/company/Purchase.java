package com.company;

import java.util.Scanner;

public abstract class Purchase implements Receipt{
    private int itemCode;
    private float amount;

    //Constructor without parameters
    public Purchase(){
        itemCode = 0;
        amount = 0.0f;
    }

    //Constructor with parameters
    public Purchase(int iC, float am){
        itemCode = iC;
        amount = am;
    }

    //Functions set and get
    public void setItemCode(int iC){
        itemCode = iC;
    }

    public void setAmount(float am){
        amount = am;
    }

    public int getItemCode() {
        return itemCode;
    }

    public float getAmount() {
        return amount;
    }

    //Function read
    public void read(){
        Scanner input = new Scanner(System.in);
        int itemCode;
        float amount;

        //Check for the item code
        do{
            System.out.println("Type the Item Code:");
            itemCode = input.nextInt();
            if(itemCode <=0){
                System.out.println("Error.Item Code must be a positive number");
            }
        }while(itemCode <=0);

        //Check for the amount
        do {
            System.out.println("Type the amount:");
            amount = input.nextFloat();
            if(itemCode <= 0){
                System.out.println("Error.Amount cannot be a negative number");
            }

        }while(amount <= 0.0f);

        this.itemCode = itemCode;
        this.amount = amount;
    }

    //Overriding toString
    @Override
    public String toString(){
        return "Item Code:"+this.itemCode+"\nAmount:"+this.amount+"\n";
    }

    //Overriding calculateAmount
    @Override
    public float calculateAmount(){
        float amount;

        amount = this.amount + this.amount*(24.0f/100.0f);

        return amount;
    }

}
