package com.company;

public interface Receipt {
    float calculateAmount();
}
