package com.company;

import java.util.ArrayList;
import java.util.Scanner;

public class Sales {
    private String company;
    private String day; // Type HH/MM//EEEE -> day/month/year
    ArrayList<Receipt> purchases = new ArrayList<>();

    //Constructor without parameters
    public Sales(){
        company = " ";
        this.purchases = new ArrayList<>();
    }

    //Set and get functions
    public void setCompany(String company) {
        this.company = company;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getCompany(){
        return company;
    }

    public String getDay() {
        return day;
    }

    //Adding the purchases into the array
    public void setPurchases(Receipt p){
        purchases.add(p);
    }

    //Private function for checking if the date is correct
    private int checkDate(String date){
        int check = 0;

        if((date.charAt(0) >= 48 && date.charAt(0) <= 51) && (date.charAt(1)>=48 && date.charAt(1)<=57)){
            if((date.charAt(0)==51 && (date.charAt(1) != 48 && date.charAt(1) != 49)) || (date.charAt(0)==48 && date.charAt(1)==48)){
                check = 0;
            }
            else{
                if(date.charAt(2) == '/' && date.charAt(5) == '/'){
                    if((date.charAt(3) == 48 || date.charAt(3) == 49) && (date.charAt(4) >= 48 && date.charAt(4) <= 57)){
                        if((date.charAt(3) == 49 && (date.charAt(4) < 48 || date.charAt(4) > 50)) || (date.charAt(3)==48 && date.charAt(4)==48)){
                            check = 0;
                        }
                        else{
                            check = 1;
                        }
                    }
                }
            }
        }



        return check;
    }

    //Function read
    public void readSales(){
        int numOfOnPUr,check=0;
        String type;
        Scanner input = new Scanner(System.in);
        Purchase p;

        //Checking if the date is correct based on the variable check, coming from the checkDate function
        do{
            System.out.println("Type the date(DD/MM/YYYY):");
            day = input.next();
            check = checkDate(day);

            if(check == 0){
                System.out.println("Error.Date must be in format \"DD/MM/YYYY\" and the date must be valid.");
            }

        }while(check == 0);


        System.out.println("Type the number of your purchases:");
        numOfOnPUr = input.nextInt();

        for(int i=0; i<numOfOnPUr; i++){
            System.out.println("Type the type of purchase number " + (i+1) + " that you made(online/shop):");
            type = input.next();

            //Simple check for the type of purchase
            if(type.toUpperCase().equals("ONLINE")){
                p = new OnlinePurchase();
                p.read();
                purchases.add(p);
            }
            else if(type.toUpperCase().equals("SHOP")){
                p = new ShopPurchase();
                p.read();
                purchases.add(p);
            }
            else{
                System.out.println("Type only \"online\" or \"shop\".");
                i--; //If the type of purchase that the user types is incorrect, we subtract 1 from the variable i, so it will ask again for the purchase type, without losing track of the total purchase number
            }
        }

    }

    //Overriding toString
    @Override
    public String toString(){
        return  "Company:" + company + "\nDay:" + day + "\nPurchases:\n" + purchases;
    }

    //Calculating the Purchase with the highest revenue
    public void highestProf(){
        float maxRev=0;
        int place = 0;

        for(int i=0; i<purchases.size(); i++){
            if(maxRev < purchases.get(i).calculateAmount()){
                maxRev = purchases.get(i).calculateAmount();
                place = i;
            }
        }
        System.out.println("The purchase with the highest revenue is:\n" + purchases.get(place).toString());
    }

    //Compares online revenue and shop revenue
    public void OnRev_ShopRev(){
        float onAmount=0, shAmount=0;

        for(Receipt p: purchases){
            if(p instanceof OnlinePurchase){
                onAmount += p.calculateAmount();
            }
            else{
                shAmount += ((ShopPurchase)p).calculateAmount();
            }
        }
        System.out.println("Online profit:" + onAmount + "\nShop profit:" + shAmount);
        if(onAmount > shAmount){
            System.out.println("The online profit is higher.");
        }
        else{
            System.out.println("The shop profit is higher.");
        }
    }

    //Calculating the Total revenue of an item
    public void TotalItemSold(int itemCode){
        int itemNum=0;
        float itemRev=0;

        for(Receipt p: purchases){
            if(p instanceof OnlinePurchase){
                if(((OnlinePurchase)p).getItemCode() == itemCode ){
                    itemNum++;
                    itemRev += ((OnlinePurchase)p).calculateAmount();
                }
            }
            else{
                if(((ShopPurchase)p).getItemCode() == itemCode ){
                    itemNum++;
                    itemRev += ((ShopPurchase)p).calculateAmount();
                }
            }

        }

        System.out.println("The item with code " + itemCode + " ,has made " + itemNum + " sales, with a total revenue of " + itemRev + "$.");
    }

    //Calculating the total revenue and prints all the purchases
    public float calculateRevenue(){
        float amount=0;

        for(Receipt p: purchases){
            amount += p.calculateAmount();
            System.out.println("Company:" + company + "\nDay:" + day + "\n" + p);
        }
        return amount;
    }
}
