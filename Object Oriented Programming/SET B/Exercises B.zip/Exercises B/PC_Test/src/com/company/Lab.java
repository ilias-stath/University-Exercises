package com.company;

import java.util.ArrayList;

public class Lab {
    private String name;
    private ArrayList<PC> computers = new ArrayList<>();

    //Constructor without parameters
    public Lab(){
        this.computers = new ArrayList<>();
    }

    //Functions set,get and addComputer
    public void setName(String name){
        this.name = name;
    }

    public String getName(){
        return this.name;
    }

    public void addComputer(PC npc){
        computers.add(npc);
    }

    //Checking if all the PC's are working and prints the ones that do not work
    public int workingPCs(){
        int j=0;

        for(PC i:computers){
            if(i.getOperational() == false){
                System.out.println(i);
            }
            else{
                j++;
            }
        }

        return j;
    }

    //Checking if there is enough free space to install an app and if there is, it installs it
    public boolean installApp(float size){
        int count=0;

        for(PC i:computers){
            if(i.getFreeSpace() >= size){
                count++;
            }
            else{
                return false; //Stopping the for because one pc can't install the app and returning false
            }
        }

        //Downloading the app, thus lowering the free space
        for(PC i:computers){
            i.setFreeSpace(i.getFreeSpace() - size);
        }

        return true;
    }

    //Changes the status of a PC
    public void pcStatus(int index, boolean status){

        computers.get(index-1).setOperational(status);
    }

    //Checking the specs of all PC's, to see if the lab can launch an app
    public boolean checkSpecs(float freq, int ram, float size){

        for(PC i:computers){
            if(i.getFreeSpace() < size || i.getFrequency() < freq || i.getRAM() < ram){
                System.out.println(i);
            }
        }
        return true;
    }

    //Overriding toString
    @Override
    public String toString(){
        return "Lab name:" + name + "\nComputers:" + computers;
    }

}
