package com.company;

import java.util.Scanner;


public class PC {
    private String processor;
    private float frequency;
    private int RAM;
    private float freeSpace;
    private boolean operational;

    //Constructor without parameters
    public PC(){
        processor = " ";
        frequency = 0;
        RAM =0;
        freeSpace = 0;
    }

    //Constructor with parameters
    public PC(String processor, float frequency, int RAM, float freeSpace, boolean operational){
        this.processor = processor;
        this.frequency = frequency;
        this.RAM = RAM;
        this.freeSpace = freeSpace;
        this.operational = operational;
    }

    //Set and get Functions
    public void setProcessor(String processor){
        this.processor = processor;
    }

    public void setFrequency(float frequency){
        this.frequency = frequency;
    }

    public void setRAM(int RAM){
        this.RAM = RAM;
    }

    public void setFreeSpace(float freeSpace){
        this.freeSpace = freeSpace;
    }

    public void setOperational(boolean operational){
        this.operational = operational;
    }

    public String getProcessor(){
        return  this.processor;
    }

    public float getFrequency(){
        return this.frequency;
    }

    public int getRAM(){
        return this.RAM;
    }

    public float getFreeSpace(){
        return this.freeSpace;
    }

    public boolean getOperational(){
        return this.operational;
    }

    //Function read
    public void read(){
        String processor,opAns;
        float frequency,freeSpace;
        int RAM,e;
        boolean operational;

        Scanner input = new Scanner(System.in);

        System.out.println("Type name of the processor:");
        processor = input.next();

        //Check for the frequency
        do{
            System.out.println("Type frequency in GHz:");
            frequency = input.nextFloat();
            if(frequency <= 0.0f){
                System.out.println("Error.Frequency must be a positive number.\n");
            }
        }while(frequency <= 0.0f);

        //Check for the RAM
        do{
            System.out.println("Type the RAM in GB:");
            RAM = input.nextInt();
            if(RAM <= 0){
                System.out.println("Error.RAM must be a positive number.\n");
            }
        }while(RAM <= 0);

        //Check for the free space
        do{
            System.out.println("Type the available free space on the hard drive in GB:");
            freeSpace = input.nextFloat();
            if(freeSpace < 0.0f){
                System.out.println("Error.The available free space can't be a negative number.\n");
            }
        }while(freeSpace < 0.0f);

        //Check for operational
        do{
            System.out.println("Type if the computer is operational(Y/N):");
            opAns = input.next();
            opAns.toUpperCase();
            if(opAns.equals("Y") || opAns.equals("N") ){
                e=1;
            }
            else{
                e=0;
                System.out.println("Error. Type only \"Y\" for YES or \"N\" for NO.\n");
            }
        }while(e==0);
        if(opAns.equals("N")){
            operational = true;
        }
        else{
            operational = false;
        }

        this.processor = processor;
        this.frequency = frequency;
        this.RAM = RAM;
        this.freeSpace = freeSpace;
        this.operational = operational;

    }

    //Overriding toString
    @Override
    public String toString(){
        return "\nProcessor:"+this.processor+"\nFrequency:"+this.frequency+"\nRAM:"+this.RAM+"\nFree Space:"+this.freeSpace+"\nOperational:"+this.operational+"\n";
    }

}
