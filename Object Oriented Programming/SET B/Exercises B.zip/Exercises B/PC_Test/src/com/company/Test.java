package com.company;


public class Test {

    public static void main(String[] args){
        //Setting the objects
        Lab l = new Lab();
        PC pc1 = new PC("Intel Core i3-12300",2.3f,8,32.3f,true);
        PC pc2 = new PC("Intel Core i5-12600",3.3f,16,523f,true);
        PC pc3 = new PC("AMD Ryzen 5 3600",3.6f,4,10f,true);
        PC pc4 = new PC("AMD Ryzen 7 5750",3.8f,16,410f,true);

        //Adding the PC's to the Lab
        l.addComputer(pc1);
        l.addComputer(pc2);
        l.addComputer(pc3);
        l.addComputer(pc4);

        //Printing the number of working PC's and the info of the PC's that do not work
        System.out.println("The number of working PCs is/are:"+l.workingPCs());
        System.out.println("-------------------");

        //Tries to install an App
        if(l.installApp(3) == true){
            System.out.println("The installation was successful");
        }
        else{
            System.out.println("The installation was not successful, due to limited free space.");
        }
        System.out.println("-------------------");

        //Prints the info from of the PCs
        System.out.println(l);

        System.out.println("-------------------");

        //Changing the status of a PC
        l.pcStatus(1,false);

        //Prints the info from of the PCs
        System.out.println(l);

        System.out.println("-------------------");

        //Printing the PC's that cannot execute the app
        System.out.println("The PCs that cannot execute this app is/are:\n");
        l.checkSpecs(2.8f,12,15.3f);

    }
}
