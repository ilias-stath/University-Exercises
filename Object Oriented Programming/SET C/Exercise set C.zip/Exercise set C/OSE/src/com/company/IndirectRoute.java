package com.company;

public class IndirectRoute extends Route{
    private String middleStop;

    // Constructor without Parameters
    public IndirectRoute(){
        super(0,0," "," ");
        middleStop = " ";
    }

    // Constructor with Parameters
    public IndirectRoute(int id, int aeroplane, String departure, String arrival, String middleStop){
        super(id, aeroplane, departure, arrival);
        this.middleStop = middleStop;
    }

    // Set and Get functions
    public void setMiddleStop(String middleStop) {
        this.middleStop = middleStop;
    }

    public String getMiddleStop() {
        return middleStop;
    }

    // Overriding Set and Get functions from Route
    @Override
    public void setId(int id) {
        super.setId(id);
    }

    @Override
    public void setAeroplane(int aeroplane) {
        super.setAeroplane(aeroplane);
    }

    @Override
    public void setDeparture(String departure) {
        super.setDeparture(departure);
    }

    @Override
    public void setArrival(String arrival) {
        super.setArrival(arrival);
    }

    @Override
    public int getId() {
        return super.getId();
    }

    @Override
    public int getAeroplane() {
        return super.getAeroplane();
    }

    @Override
    public String getDeparture() {
        return super.getDeparture();
    }

    @Override
    public String getArrival() {
        return super.getArrival();
    }


    // Overriding AddTicket Function
    @Override
    public void addTicket(Ticket t, Train a) {
        int freeSeats,numberOfPassengers=0;

        for(Ticket i: super.tickets){
            numberOfPassengers++;
        }

        // Exceptions for addTicket
        try{
            freeSeats = a.getMaxPassenger() - numberOfPassengers;
            if(freeSeats <= 0){
                throw new NullPointerException();
            }
            else if(t.getId() != super.getId()){
                throw new RuntimeException();
            }

            if((t.getDeparture().equals(super.getDeparture()) ||t.getDeparture().equals(middleStop) )&& t.getArrival().equals(super.getArrival())){
                System.out.println("The ticket has successfully registered.");
                tickets.add(t);
            }
            else{
                throw new Exception();
            }
        }catch (NullPointerException n){
            System.out.println("The are not any empty seats.");
        }
        catch (RuntimeException r){
            System.out.println("The id from the ticket is different from id of the route");
        }catch (Exception e){
            System.out.println("The Departure and arrival stations from the ticket, do not match the ones in the route.");
        }
    }


    // Finalize Function
    public String Finalize(){

        int numOfPass=0;

        for(Ticket t: super.tickets){
            if (t.getArrival().equals(super.getArrival()) ){
                numOfPass++;
            }
        }

        if(numOfPass <= 0){
            return toString() + "\nThe route will be canceled due to lack of passengers." + "\n";
        }
        else{
            return toString() + "\nThe route will continue as normal." + "\n";
        }
    }

    // Overriding the function toString
    @Override
    public String toString(){
        return super.toString() + "Middle Stop:" + middleStop;
    }
}
