package com.company;

public class Main {
    public static void main(String[] args){
        // Creating objects
        Train tr1 = new Train(4,"SilverArrow",40);
        Train tr2 = new Train(10,"Coal",70);
        Train tr3 = new Train(4,"Electrical",80);
        Ticket ti1 = new Ticket(1,"Konio","k","a",4.0f,2.1f);
        Ticket ti2 = new Ticket(2,"Kokos","e","c",0.0f,2.1f);
        Route d1 = new Route(1,4,"k","a");
        IndirectRoute d2 = new IndirectRoute(2,10,"e","c","d");
        Route d3 = new Route(3,8,"g","b");

        // Adding tickets to routes
        d1.addTicket(ti1,tr1);
        d2.addTicket(ti2,tr2);

        // Printing Finilizes
        System.out.println("--------");
        System.out.println(d1.Finalize());
        System.out.println("---------");
        System.out.println(d2.Finalize());
        System.out.println("----------");
        System.out.println(d3.Finalize());


    }
}
