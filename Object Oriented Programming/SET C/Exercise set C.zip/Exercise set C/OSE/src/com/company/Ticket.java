package com.company;

import java.util.Scanner;

public class Ticket {
    private int id;
    private String passenger;
    private String departure;
    private String arrival;
    private float distance;
    private float cost;

    // Constructor without Parameters
    public Ticket(){
        id = 0;
        passenger = " ";
        departure = " ";
        arrival = " ";
        distance = 0.0f;
        cost = 0.0f;
    }

    // Constructor with Parameters
    public  Ticket(int id, String passenger, String departure, String arrival, float distance, float cost){
        this.id = id;
        this.passenger = passenger;
        this.departure = departure;
        this.arrival = arrival;
        this.distance = distance;
        this.cost = cost;
    }

    // Set and Get functions
    public void setId(int id) {
        this.id = id;
    }

    public void setPassenger(String passenger) {
        this.passenger = passenger;
    }

    public void setDeparture(String departure) {
        this.departure = departure;
    }

    public void setArrival(String arrival) {
        this.arrival = arrival;
    }

    public void setDistance(float distance) {
        this.distance = distance;
    }

    public void setCost(float cost) {
        this.cost = cost;
    }

    public int getId() {
        return id;
    }

    public String getPassenger() {
        return passenger;
    }

    public String getDeparture() {
        return departure;
    }

    public String getArrival() {
        return arrival;
    }

    public float getDistance() {
        return distance;
    }

    public float getCost() {
        return cost;
    }

    // Read Function
    public void read(){
        Scanner input = new Scanner(System.in);
        int id;
        String passenger,departure,arrival;
        float distance,cost=0;
        boolean costPos = false;

        // Check for id
        do{
            System.out.println("Type the route id:");
            id = input.nextInt();
            if(id <= 0){
                System.out.println("Id must me a positive number.");
            }
        }while(id <= 0);

        // Check for passenger name
        do {
            System.out.println("Type name of the passenger:");
            passenger = input.next();
            if(passenger.equals(" ")){
                System.out.println("Name cannot be empty.");
            }
        }while(passenger.equals(" "));

        // Check for departure station
        do {
            System.out.println("Type the departure station:");
            departure = input.next();
            if(departure.equals(" ")){
                System.out.println("Departure station cannot be empty.");
            }
        }while(departure.equals(" "));

        // Check for arrival station
        do {
            System.out.println("Type the arrival station:");
            arrival = input.next();
            if(arrival.equals(" ")){
                System.out.println("Arrival station cannot be empty.");
            }
        }while(arrival.equals(" "));

        // Check for distance
        do {
            System.out.println("Type the distance:");
            distance = input.nextFloat();
            if(distance <= 0.0f){
                System.out.println("Distance must be a positive number.");
            }
        }while(distance <= 0.0f);

        // Check for cost
        while(!costPos){
            // Exception for cost
            try{
                System.out.println("Type the cost:");
                cost = input.nextFloat();
                if(cost <= 0 ){
                    throw new Exception();
                }
                else {
                    costPos = true;
                }
            }catch(Exception e){
                System.out.println("Cost cannot be negative or zero.");
                System.out.println("Based on the distance, cost must be:" + (0.25*distance));
            }
        }

        this.id = id;
        this.passenger = passenger;
        this.departure = departure;
        this.arrival = arrival;
        this.distance = distance;
        this.cost = cost;
    }

    // Overriding the function toString
    @Override
    public String toString(){
        return "Route id:" + id + "\nPassenger:" + passenger + "\nDeparture:" + departure + "\nArrival:" + arrival + "\nDistance:" + distance + "\nCost:" + cost;
    }
}
