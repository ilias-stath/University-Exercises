package com.company;

import java.util.Scanner;

public class Train {
    private int id;
    private String model;
    private int maxPassenger;

    // Constructor without Parameters
    public Train(){
        id = 0;
        model = " ";
        maxPassenger = 0;
    }

    // Constructor with Parameters
    public Train(int id, String model, int maxPassenger){
        this.id = id;
        this.model = model;
        this.maxPassenger = maxPassenger;
    }

    // Set and Get functions
    public void setId(int id) {
        this.id = id;
    }

    public void setMaxPassenger(int maxPassenger) {
        this.maxPassenger = maxPassenger;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getId() {
        return id;
    }

    public int getMaxPassenger() {
        return maxPassenger;
    }

    public String getModel() {
        return model;
    }

    // Read Function
    public void read(){
        int id,maxPassenger;
        String model;
        Scanner input = new Scanner(System.in);

        // Check for id
        do{
            System.out.println("Type the train id:");
            id = input.nextInt();
            if(id<=0){
                System.out.println("Id must me a positive number.");
            }
        }while(id <= 0);

        // Check for train model
        do{
            System.out.println("Type the train model:");
            model = input.next();;
            if(model.equals(" ")){
                System.out.println("Train model cannot be empty.");
            }
        }while(model.equals(" "));

        // Check for maximum passenger capacity
        do{
            System.out.println("Type number of the maximum passengers for the train:");
            maxPassenger = input.nextInt();
            if(maxPassenger<=0){
                System.out.println("Passenger capacity must me a positive number.");
            }
        }while(maxPassenger<=0);

        this.id = id;
        this.maxPassenger =maxPassenger;
        this.model = model;
    }

    // Overriding the function toString
    @Override
    public String toString(){
        return "Train id:" + id + "\nTrain model:" + model + "\nPassenger capacity of train:" + maxPassenger + "\n";
    }
}
