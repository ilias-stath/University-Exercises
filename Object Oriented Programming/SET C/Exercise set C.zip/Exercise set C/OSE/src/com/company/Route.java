package com.company;

import java.util.Scanner;
import java.util.ArrayList;

public class Route {
    private int id;
    private int aeroplane;
    private String departure;
    private String arrival;
    ArrayList<Ticket> tickets = new ArrayList<>();

    // Constructor without Parameters
    public Route(){
        id = 0;
        aeroplane = 0;
        departure = " ";
        arrival = " ";
    }

    // Constructor with Parameters
    public Route(int id, int aeroplane, String departure, String arrival){
        this.id = id;
        this.aeroplane = aeroplane;
        this.departure = departure;
        this.arrival = arrival;
    }

    // Set and Get functions
    public void setId(int id) {
        this.id = id;
    }

    public void setAeroplane(int aeroplane) {
        this.aeroplane = aeroplane;
    }

    public void setDeparture(String departure) {
        this.departure = departure;
    }

    public void setArrival(String arrival) {
        this.arrival = arrival;
    }

    public int getId() {
        return id;
    }

    public int getAeroplane() {
        return aeroplane;
    }

    public String getDeparture() {
        return departure;
    }

    public String getArrival() {
        return arrival;
    }

    // AddTicket Function
    public void addTicket(Ticket t, Train a){
        int freeSeats,numberOfPassengers=0;

        // Calculating total passengers
        for(Ticket i: tickets){
            numberOfPassengers++;
        }

        // Exceptions for addTicket
        try{
            freeSeats = a.getMaxPassenger() - numberOfPassengers;
            if(freeSeats <= 0){
                throw new NullPointerException();
            }
            else if(t.getId() != id){
                throw new RuntimeException();
            }

            if(t.getDeparture().equals(departure) && t.getArrival().equals(arrival)){
                System.out.println("The ticket has successfully registered.");
                tickets.add(t);
            }
            else{
                throw new Exception();
            }
        }catch (NullPointerException n){
            System.out.println("The are not any empty seats.");
        }
        catch (RuntimeException r){
            System.out.println("The id from the ticket is different from id of the route");
        }catch (Exception e){
            System.out.println("The Departure and arrival stations from the ticket, do not match the ones in the route.");
        }
    }

    // Finalize Function
    public String Finalize(){
        int numOfPass=0;

        for(Ticket t: tickets){
            numOfPass++;
        }

        if(numOfPass <= 0){
            return toString() + "\nThe route will be canceled due to lack of passengers." + "\n";
        }
        else{
            return toString() + "\nThe route will continue as normal." + "\n";
        }
    }

    // Overriding the function toString
    @Override
    public String toString(){
        return "Route id:" + id + "\nTrain id:" + aeroplane + "\nDeparture:" + departure + "\nArrival:" + arrival + "\n\nTickets:\n" + tickets + "\n";
    }
}
