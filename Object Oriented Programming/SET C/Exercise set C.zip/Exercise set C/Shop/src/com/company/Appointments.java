package com.company;

import java.util.Scanner;

public class Appointments {
    private final int id;
    private static int numOfAp=0;
    private String employee;
    private String customer;

    public Appointments(){
        numOfAp++;
        id = numOfAp;
        employee = " ";
        customer = " ";

    }

    public Appointments(String employee, String customer){
        this.employee = employee;
        this.customer = customer;
        numOfAp++;
        id = numOfAp;

    }

    public void setEmployee(String employee) {
        this.employee = employee;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    public int getId() {
        return id;
    }

    public static int getNumOfAp() {
        return numOfAp;
    }

    public String getEmployee() {
        return employee;
    }

    public String getCustomer() {
        return customer;
    }

    public void read(){
        Scanner input = new Scanner(System.in);
        String employee,customer;


        do{
            System.out.println("Type the name of the employee:");
            employee = input.next();
            if(employee.equals(" ")){
                System.out.println("Employee name cannot be empty.");
            }
        }while(employee.equals(" "));

        System.out.println("Type the name of the customer:");

        do{
            System.out.println("Type the name of the customer:");
            customer = input.next();
            if(customer.equals(" ")){
                System.out.println("customer name cannot be empty.");
            }
        }while(customer.equals(" "));

        this.customer = customer;
        this.employee = employee;
    }

    public synchronized int nextCustomer(int employeeId){


        return 1;
    }

    @Override
    public String toString(){
        return "Appointment id:" + id + "\nEmployee name:" + employee + "\nCustomer name:" + customer;
    }
}
