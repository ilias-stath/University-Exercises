package com.company;


import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        // Creating objects
        TakeNumber number = new TakeNumber();
        ArrayList<Appointments> App = new ArrayList<>();
        Customer C1 = new Customer("Ilias",number);
        Customer C2 = new Customer("Stelios",number);
        Customer C3 = new Customer("Maria",number);
        Customer C4 = new Customer("Giannis",number);
        Customer C5 = new Customer("Gianna",number);
        Customer C6 = new Customer("Kostas",number);
        Customer C7 = new Customer("Petros",number);
        Customer C8 = new Customer("Evangelos",number);
        Customer C9 = new Customer("Evangelia",number);
        Customer C10 = new Customer("Katerina",number);
        Customer C11 = new Customer("Konstantina",number);
        Customer C12 = new Customer("Eua",number);
        Customer C13 = new Customer("Mick",number);
        Customer C14 = new Customer("Lara",number);
        Customer C15 = new Customer("Ilias",number);
        Customer C16 = new Customer("Petroula",number);
        Customer C17 = new Customer("John",number);
        Customer C18 = new Customer("Panos",number);
        Customer C19 = new Customer("Zoi",number);
        Customer C20 = new Customer("Dimitris",number);

        Employee E1 = new Employee("Stelios",number);
        Employee E2 = new Employee("Ilias",number);
        Employee E3 = new Employee("Christine",number);

        // Starting threads
        E1.start();
        E2.start();
        E3.start();
        C1.start();
        C2.start();
        C3.start();
        C4.start();
        C5.start();
        C6.start();
        C7.start();
        C8.start();
        C9.start();
        C10.start();
        C11.start();
        C12.start();
        C13.start();
        C14.start();
        C15.start();
        C16.start();
        C17.start();
        C18.start();
        C19.start();
        C20.start();
        for(int i=0; i<20; i++){
            App.add(number.getAppointment());
        }

        // Printing out ArrayList
        for(Appointments a:App){
            System.out.println(a);
        }
        
    }
}
