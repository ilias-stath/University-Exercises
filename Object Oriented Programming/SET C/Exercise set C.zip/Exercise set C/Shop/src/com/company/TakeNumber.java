package com.company;

public class TakeNumber {
    private int nextCust = 0;
    private int servingCust = 0;
    private int id=0;
    private String customerName;
    private Appointments appointment;

    // Get appointment Function
    Appointments getAppointment() {
        return appointment;
    }

    // Synchronized get customer info Function
    public synchronized void getCustInfo(String name){
        customerName = name;
        id++;
    }

    // Synchronized next customer Function
    public synchronized void nextCustomer(int empId, String empName){
        /*try{
            while(nextCust <= servingCust){
                System.out.println("\nEmploye "+ empId+" is waiting.");
                wait();
            }


        }catch (InterruptedException e){
            e.getStackTrace();
            Appointments a = new Appointments();
        }*/
        System.out.println("\nClerk  "+ empId+" serving customer with id " + id);
        Appointments app = new Appointments(empName,customerName);
        System.out.println(app);
        this.appointment = app;
    }
}
