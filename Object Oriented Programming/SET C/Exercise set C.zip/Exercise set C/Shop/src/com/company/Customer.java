package com.company;

import java.util.Scanner;

public class Customer extends Thread{
    private String name;
    private TakeNumber number;

    // Constructor without parameters
    public Customer(){
        name = " ";
        number = new TakeNumber();
    }

    // Constructor with parameters
    public Customer(String name, TakeNumber number){
        this.name = name;
        this.number = number;
    }

    // Set and Get Functions
    public void setname(String name) {
        this.name = name;
    }

    public String getname() {
        return name;
    }

    // Read Function
    public void read(){
        String name;
        Scanner input = new Scanner(System.in);

        // Check for employee name
        do{
            System.out.println("Type the name of the customer.");
            name = input.next();
            if(name.equals(" ")){
                System.out.println("Name cannot be empty.");
            }

        }while(name.equals(" "));
    }

    // Run Thread-Function
    public void run(){
        try{
            Thread.sleep((long)(Math.random()*3000) + 2000);
            number.getCustInfo(name);
        }
        catch (InterruptedException e){
            e.getStackTrace();
        }
    }

    // Overriding toString Function
    @Override
    public String toString(){
        return "Customer name:" + name ;
    }
}
