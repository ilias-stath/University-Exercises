package com.company;

import java.util.Scanner;

public class Employee extends Thread{
    private final int id;
    private static int numOfEmp;
    private String name;
    private TakeNumber number;

    // Constructor without parameters
    public Employee(){
        name = " ";
        numOfEmp++;
        id = numOfEmp;
    }

    // Constructor with parameters
    public Employee(String name, TakeNumber number){
        this.name = name;
        numOfEmp++;
        id = numOfEmp;
        this.number = number;
    }

    // Set and Get Functions
    public void setname(String name) {
        this.name = name;
    }

    public int getid() {
        return id;
    }

    public static int getNumOfEmp() {
        return numOfEmp;
    }

    public String getname(){
        return name;
    }

    // Read Function
    public void read(){
        String name;
        Scanner input = new Scanner(System.in);

        // Check for employee name
        do{
            System.out.println("Type the name of th employee.");
            name = input.next();

            if(name.equals(" ")){
                System.out.println("Name cannot be empty.");
            }

        }while(name.equals(" "));

        this.name = name;

    }

    // Run Thread-Function
    public void run(){
        try{
            Thread.sleep((long)(Math.random()*5000) + 5000);
            number.nextCustomer(id,name);
        }
        catch(InterruptedException e){
            e.getStackTrace();
        }

    }

    // Overriding toString Function
    @Override
    public String toString(){
        return "Employee name:" + name +"\nEmployee id:" + id;
    }

}
