package Acc;

import java.util.Scanner;

public class Account {

    // fields
    private final int accNum;
    private  String name;
    private double balance;
    private double  blockedAmount;
    private static int count=0;
    //constructor
    public Account(){
        accNum = ++count;//automating numbering .The accNum rises each time by 1
        balance = 0;
        blockedAmount = 0;
        name = " ";
    }
    public Account(String onoma , double poso){
        balance=poso;
        name=onoma;
        accNum = ++count;
    }
    // functions
    public  void Read(){//it reads data from the user
        Scanner input = new Scanner(System.in);
        System.out.println("Please enter name");
        name = input.next();
        System.out.println("Please enter your account balance");
        do{
            balance = input.nextDouble();
            if(balance<0){
                System.out.println("Please reenter your account balance.Acc.Account balance >0");
            }
        }while(balance<0);
    }
    //return each data from the fields
    public  int getAccNumber(){
        return accNum;
    }
    public   String getName(){
        return name;
    }
    public    double getBalance(){
        return balance;
    }
    public double getAvailableBalance(){
        return balance - blockedAmount;

    }
    // withdrawal amount from the account
     public  void  withdraw(double amount){
        double avbalance=getAvailableBalance();
        if((avbalance) >= amount)
        {
            balance -= amount;

        }

        else
            System.out.println("There aren't enough money in your account");

        }

     // it deposits amount to the account
     public void deposit(double amount){
        balance = balance + amount;
     }
     // it completes card purchase
      public void cardPurchase(double amount ){
          double avbalance=getAvailableBalance();
        if( avbalance>= amount){
            blockedAmount = blockedAmount + amount;
        }
        else
            System.out.println("There aren't enough money to complete this transaction");
     }
     // withdrawal from blocked amount
     public void withdrawBlockedAmount(double amount){
        if(amount <= blockedAmount){
            blockedAmount = blockedAmount - amount;
            balance = balance - amount;
        }
        else
            System.out.println("There aren't enough money to complete this withdrawal");
     }
     // it prints the data from the  account
     public void print(){
        System.out.println("Acc.Account number: "+getAccNumber());
        System.out.println("Owner: "+getName());
        System.out.println("Balance: "+getBalance());
        System.out.println("Blocked amount: "+blockedAmount);
        System.out.println("Available balance: "+getAvailableBalance());
        System.out.println("\n");

     }

}
