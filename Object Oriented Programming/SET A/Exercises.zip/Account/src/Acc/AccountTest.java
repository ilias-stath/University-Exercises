package Acc;

import Acc.Account;

import java.util.Scanner;
public class AccountTest {
    private static final int N=5;
    public static void PrintMenu(){
        System.out.println("Press '1' to deposit");
        System.out.println("Press '2' to withdrawal");
        System.out.println("Press '3' for card purchase");
        System.out.println("Press '4' for professional withdrawal from a committed amount");
        System.out.println("Press '5' for account data");
        System.out.println("Press '6' for account with most money");
        System.out.println("Press '7' for exit");
    }
    public static void main(String[] args) {
        double amount;
        int command=0;
        int acc_num=0;
        Account[] Array = new Account[N];
        //declaration of the array
        Array[0] = new Account("Stelios",500);
        Array[1] = new Account("Maria",1000);
        Array[2] = new Account("Ilias",200.5);
        Array[3] = new Account("Thomas",300);
        Array[4] = new Account("Katerina",600);
        Scanner input = new Scanner(System.in);
        do{
            PrintMenu();
            command = input.nextInt();
            switch (command){
                case 1:
                    System.out.println("Enter the account number.(1 to 5)");
                    acc_num = input.nextInt();
                    System.out.println("Enter the amount you want to deposit");
                    amount = input.nextDouble();
                    Array[acc_num - 1].deposit(amount);
                    break;
                case 2:
                    System.out.println("Enter the account number.(1 to 5)");
                    acc_num = input.nextInt();
                    System.out.println("Enter the amount you want to withdrawal");
                    amount = input.nextDouble();
                    Array[acc_num - 1].withdraw(amount);
                    break;
                case 3:
                    System.out.println("Enter the account number.(1 to 5)");
                    acc_num = input.nextInt();
                    System.out.println("Enter the amount that you want to buy");
                    amount = input.nextDouble();
                    Array[acc_num - 1].cardPurchase(amount);
                    break;
                case 4:
                    System.out.println("Enter the account number.(1 to 5)");
                    acc_num = input.nextInt();
                    System.out.println("Enter the amount that you wan to take");
                    amount = input.nextDouble();
                    Array[acc_num - 1].withdrawBlockedAmount(amount);
                    break;
                case 5:
                    System.out.println("Enter the account number.(1 to 5)");
                    acc_num = input.nextInt();
                    Array[acc_num - 1].print();
                    break;
                case 6:
                    double max = Array[0].getAvailableBalance();
                    int index=0;
                    for(int i=0; i< Array.length; i++){
                        if(Array[i].getAvailableBalance() > max){
                            max = Array[i].getAvailableBalance();
                            index = i;
                        }
                    }
                    System.out.println("\t\t\t\tThe account with the highest available balance");
                    Array[index].print();
                    break;
                case 7:
                    break;
                default:
                    System.out.println("Wrong choice");
                    break;
            }
        }while(command!=7);
    }
}
