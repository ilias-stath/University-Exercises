package com.company;
import java.util.Scanner;
import java.lang.Math;

public class Main {

    public static void main(String[] args) {

        //Declaration of variables
        int num,factorial=1,i,sum=0,len=0;
        boolean higherThanOne = true;
        Scanner input = new Scanner(System.in);

        //Check if the number is positive
        System.out.println("Give a positive integer number");
        do{
            System.out.print("Number:");
            num = input.nextInt();
            if(num <= 0){
                System.out.println("Error. You must give a positive integer number.");
            }
        }while(num <= 0);

        //Calculate the factorial
        while(higherThanOne){
            factorial *= num;
            if(num > 1){
                num--;
            }
            else{
                higherThanOne = false;
            }
        }
        System.out.println("Factorial = " + factorial);

        //Find the number of digits based on the powers of 10
        for(i=1; i<i+2; i++){
            if(factorial < (int)Math.pow(10,i)){
                len = i;
                break;
            }
        }

        //Calculate the sum of the digits
        while(len > 0){
            sum += factorial/(int)Math.pow(10,len-1);
            factorial = factorial%(int)Math.pow(10,len-1);
            len--;
        }

        System.out.println("Sum of digits = " + sum);
    }
}
